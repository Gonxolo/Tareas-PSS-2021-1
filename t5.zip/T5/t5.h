double viajante(int z[], int n, double **m, int nperm);
double viajante_par(int z[], int n, double **m, int nperm, int p);
