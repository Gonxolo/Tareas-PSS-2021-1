char *ultimaDireccionValida(char *ptr);
