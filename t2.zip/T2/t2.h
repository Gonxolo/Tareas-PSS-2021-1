int aislar_palabras(char *s);
char *palabras(char *s);
